function D = TranslationMatrix(r)
    D = [eye(3) r;0 0 0 1];
end