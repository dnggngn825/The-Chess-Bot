function [X_chess, Y_chess, width_chess, singleSquare]= ChessboardSpec()
X_chess = 240;
Y_chess = 0;
width_chess = 320;
singleSquare = width_chess/8;
end